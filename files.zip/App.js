import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [content, setContent] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/content')
      .then(response => {
        setContent(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the content!', error);
      });
  }, []);

  return (
    <div className="App">
      <h1>Content</h1>
      <ul>
        {content.map(item => (
          <li key={item._id}>{item.title}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;