const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./User');

const Content = sequelize.define('Content', {
  title: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  body: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  published: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
}, { timestamps: true });

Content.belongsTo(User, { foreignKey: 'authorId' });

module.exports = Content;