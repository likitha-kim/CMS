const express = require('express');
const Content = require('../models/Content');
const auth = require('../middlewares/auth');

const router = express.Router();

// Create content
router.post('/', auth, async (req, res) => {
  const { title, body } = req.body;

  try {
    const newContent = await Content.create({ title, body, authorId: req.user.userId });
    res.status(201).send('Content created');
  } catch (err) {
    res.status(500).send('Server error');
  }
});

// Get all content
router.get('/', auth, async (req, res) => {
  try {
    const content = await Content.findAll({ include: 'User' });
    res.json(content);
  } catch (err) {
    res.status(500).send('Server error');
  }
});

// Update content
router.put('/:id', auth, async (req, res) => {
  const { title, body, published } = req.body;

  try {
    const content = await Content.findByPk(req.params.id);
    if (!content) return res.status(404).send('Content not found');

    if (content.authorId !== req.user.userId && req.user.role !== 'admin') return res.status(401).send('Access denied');

    content.title = title;
    content.body = body;
    content.published = published;
    await content.save();
    res.send('Content updated');
  } catch (err) {
    res.status(500).send('Server error');
  }
});

// Delete content
router.delete('/:id', auth, async (req, res) => {
  try {
    const content = await Content.findByPk(req.params.id);
    if (!content) return res.status(404).send('Content not found');

    if (content.authorId !== req.user.userId && req.user.role !== 'admin') return res.status(401).send('Access denied');

    await content.destroy();
    res.send('Content deleted');
  } catch (err) {
    res.status(500).send('Server error');
  }
});

module.exports = router;